import Directory from '../../components/directory/directory';
// import { Outlet } from 'react-router-dom';

const Home = () => {
  return (
    <>
      <Directory />
    </>
  );
};

export default Home;
